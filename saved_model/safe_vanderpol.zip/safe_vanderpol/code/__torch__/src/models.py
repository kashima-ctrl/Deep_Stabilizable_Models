class Safty_Dynamics(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  device : Device
  state_dim : int
  action_dim : int
  c4 : int
  f_hat : __torch__.torch.nn.modules.container.Sequential
  alpha : __torch__.torch.nn.modules.container.___torch_mangle_3.Sequential
  g : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.src.models.Safty_Dynamics,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
    f_hat = self.f_hat
    f_hat0 = torch.unsqueeze((f_hat).forward(x, ), 2)
    alpha = self.alpha
    alpha0 = torch.unsqueeze((alpha).forward(x, ), 2)
    _0 = annotate(List[Tensor], [])
    g = self.g
    _00 = getattr(g, "0")
    _1 = (_00).forward(x, )
    state_dim = self.state_dim
    _2 = torch.reshape(_1, [-1, state_dim, 1])
    _3 = torch.append(_0, _2)
    g0 = torch.squeeze(torch.stack(_0, 2), 3)
    eta = torch.reshape(__torch__.eta(x, ), [-1, 1, 1])
    _4 = torch.autograd.grad([torch.sum(eta)], [x], None, None, True)
    grad_eta = _4[0]
    if torch.__isnot__(grad_eta, None):
      grad_eta1 = unchecked_cast(Tensor, grad_eta)
      grad_eta0 = torch.unsqueeze(grad_eta1, 2)
    else:
      device = self.device
      grad_eta2 = torch.zeros_like(x, dtype=6, layout=None, device=device)
      grad_eta0 = grad_eta2
    _5 = torch.transpose(grad_eta0, 1, 2)
    _6 = torch.add(f_hat0, torch.matmul(g0, alpha0))
    _7 = torch.matmul(_5, _6)
    c4 = self.c4
    _8 = torch.neg(torch.add(_7, torch.mul(eta, c4)))
    _9 = torch.sum(torch.pow(grad_eta0, 2), [1], True)
    _10 = torch.add(_9, 9.9999999999999995e-07)
    criterion = torch.relu(torch.div(_8, _10))
    fs = torch.mul(criterion, grad_eta0)
    f = torch.add(f_hat0, fs)
    return (f, g0, alpha0, eta)

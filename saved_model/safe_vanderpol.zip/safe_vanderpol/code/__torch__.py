def eta(x: Tensor) -> Tensor:
  _0 = torch.sub(torch.select(torch.slice(x), 1, 0), 1.5)
  _1 = torch.pow(_0, 2)
  _2 = torch.pow(torch.select(torch.slice(x), 1, 1), 2)
  _3 = torch.add(torch.neg(torch.add(_1, _2)), 1)
  return _3

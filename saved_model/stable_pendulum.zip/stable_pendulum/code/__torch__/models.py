class Stable_Dynamics(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  device : Device
  state_dim : int
  action_dim : int
  x_stable : Tensor
  f_hat : __torch__.torch.nn.modules.container.Sequential
  lyapunov_function : __torch__.networks.LyapunovFunction
  alpha_hat : __torch__.torch.nn.modules.container.___torch_mangle_6.Sequential
  g : __torch__.torch.nn.modules.container.___torch_mangle_7.ModuleList
  def forward(self: __torch__.models.Stable_Dynamics,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
    f_hat = self.f_hat
    _0 = (f_hat).forward(x, )
    f_hat0 = self.f_hat
    x_stable = self.x_stable
    _1 = torch.sub(_0, (f_hat0).forward(x_stable, ))
    f0 = torch.unsqueeze(_1, 2)
    alpha_hat = self.alpha_hat
    _2 = (alpha_hat).forward(x, )
    alpha_hat0 = self.alpha_hat
    x_stable0 = self.x_stable
    _3 = torch.sub(_2, (alpha_hat0).forward(x_stable0, ))
    alpha = torch.unsqueeze(_3, 2)
    _4 = annotate(List[Tensor], [])
    g = self.g
    _00 = getattr(g, "0")
    _5 = (_00).forward(x, )
    state_dim = self.state_dim
    _6 = torch.reshape(_5, [-1, state_dim, 1])
    _7 = torch.append(_4, _6)
    g0 = torch.squeeze(torch.stack(_4, 2), 3)
    lyapunov_function = self.lyapunov_function
    V = (lyapunov_function).forward(x, )
    torch.autograd.backward(torch.sum(V))
    grad_V = torch.unsqueeze(ops.prim.grad(x), 2)
    _8 = torch.sum(torch.pow(x, 2), [1], True)
    W = torch.mul(torch.unsqueeze(_8, 2), 0.10000000000000001)
    _9 = torch.transpose(grad_V, 1, 2)
    _10 = torch.add(f0, torch.matmul(g0, alpha))
    criterion = torch.add(torch.matmul(_9, _10), W)
    _11 = torch.neg(criterion)
    _12 = torch.sum(torch.pow(grad_V, 2), [1], True)
    _13 = torch.add(_12, 9.9999999999999995e-07)
    fs = torch.mul(torch.div(_11, _13), grad_V)
    mask = torch.le(criterion, 0)
    f = torch.where(mask, f0, torch.add(f0, fs))
    return (f, g0, alpha, V)

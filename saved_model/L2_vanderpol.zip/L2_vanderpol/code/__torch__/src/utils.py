class SmoothReLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  d : float
  def forward(self: __torch__.src.utils.SmoothReLU,
    x: Tensor) -> Tensor:
    _0 = torch.le(x, 0)
    _1 = torch.zeros_like(x)
    d = self.d
    _2 = torch.lt(x, d)
    _3 = torch.pow(x, 2)
    d0 = self.d
    _4 = torch.div(_3, torch.mul(2, d0))
    d1 = self.d
    _5 = torch.where(_2, _4, torch.sub(x, torch.div(d1, 2)))
    return torch.where(_0, _1, _5)

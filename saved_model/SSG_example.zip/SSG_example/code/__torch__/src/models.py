class SSG_DynamicsFW(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  device : Device
  state_dim : int
  action_dim : int
  h : __torch__.torch.nn.modules.container.Sequential
  f_hhat : __torch__.torch.nn.modules.container.___torch_mangle_3.Sequential
  lyapunov_function : __torch__.torch.nn.modules.container.___torch_mangle_5.Sequential
  def forward(self: __torch__.src.models.SSG_DynamicsFW,
    x: Tensor,
    u: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    _0 = __torch__.torch.autograd.grad_mode.no_grad.__new__(__torch__.torch.autograd.grad_mode.no_grad)
    _1 = (_0).__init__()
    with _0:
      h = (self).forward_h(u, )
      hu = torch.hstack([h, u])
    xu = torch.hstack([x, u])
    f_hhat = self.f_hhat
    _2 = (f_hhat).forward(xu, )
    f_hhat0 = self.f_hhat
    _3 = torch.sub(_2, (f_hhat0).forward(hu, ))
    f_hat = torch.unsqueeze(_3, 2)
    lyapunov_function = self.lyapunov_function
    V = (lyapunov_function).forward(xu, )
    _4 = torch.autograd.grad([torch.sum(V)], [x], None, None, True)
    grad_V = _4[0]
    if torch.__isnot__(grad_V, None):
      grad_V1 = unchecked_cast(Tensor, grad_V)
      state_dim = self.state_dim
      grad_V2 = torch.reshape(grad_V1, [-1, state_dim, 1])
      grad_V0 = grad_V2
    else:
      device = self.device
      grad_V3 = torch.zeros_like(x, dtype=6, layout=None, device=device)
      grad_V0 = grad_V3
    _5 = torch.sum(torch.pow(torch.sub(x, h), 2), [1], True)
    W = torch.mul(torch.unsqueeze(_5, 2), 0.10000000000000001)
    _6 = torch.matmul(torch.transpose(grad_V0, 1, 2), f_hat)
    _7 = torch.add(_6, W)
    _8 = torch.sum(torch.pow(grad_V0, 2), [1], True)
    _9 = torch.div(_7, torch.add(_8, 0.0001))
    criterion = torch.relu(_9)
    ell_hat = torch.mul(torch.neg(criterion), grad_V0)
    f = torch.add(f_hat, ell_hat)
    return (f, h, V)
  def forward_h(self: __torch__.src.models.SSG_DynamicsFW,
    u: Tensor) -> Tensor:
    h = self.h
    return (h).forward(u, )

class Passification_Dynamics(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  device : Device
  state_dim : int
  action_dim : int
  x_stable : Tensor
  f_hat : __torch__.torch.nn.modules.container.Sequential
  lyapunov_function : __torch__.src.networks.LyapunovFunction
  alpha_hat : __torch__.torch.nn.modules.container.___torch_mangle_6.Sequential
  g : __torch__.torch.nn.modules.container.___torch_mangle_7.ModuleList
  beta : __torch__.torch.nn.modules.container.___torch_mangle_8.ModuleList
  def forward(self: __torch__.src.models.Passification_Dynamics,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor, Tensor]:
    f_hat = self.f_hat
    _0 = (f_hat).forward(x, )
    f_hat0 = self.f_hat
    x_stable = self.x_stable
    _1 = torch.sub(_0, (f_hat0).forward(x_stable, ))
    f0 = torch.unsqueeze(_1, 2)
    alpha_hat = self.alpha_hat
    _2 = (alpha_hat).forward(x, )
    alpha_hat0 = self.alpha_hat
    x_stable0 = self.x_stable
    _3 = torch.sub(_2, (alpha_hat0).forward(x_stable0, ))
    alpha = torch.unsqueeze(_3, 2)
    _4 = annotate(List[Tensor], [])
    g = self.g
    _00 = getattr(g, "0")
    _5 = (_00).forward(x, )
    state_dim = self.state_dim
    _6 = torch.reshape(_5, [-1, state_dim, 1])
    _7 = torch.append(_4, _6)
    g0 = torch.squeeze(torch.stack(_4, 2), 3)
    _8 = annotate(List[Tensor], [])
    beta = self.beta
    _01 = getattr(beta, "0")
    _9 = (_01).forward(x, )
    action_dim = self.action_dim
    _10 = torch.reshape(_9, [-1, action_dim, 1])
    _11 = torch.append(_8, _10)
    beta0 = torch.squeeze(torch.stack(_8, 2), 3)
    lyapunov_function = self.lyapunov_function
    V = (lyapunov_function).forward(x, )
    _12 = torch.autograd.grad([torch.sum(V)], [x], None, None, True)
    grad_V = _12[0]
    if torch.__isnot__(grad_V, None):
      grad_V1 = unchecked_cast(Tensor, grad_V)
      state_dim0 = self.state_dim
      grad_V2 = torch.reshape(grad_V1, [-1, state_dim0, 1])
      grad_V0 = grad_V2
    else:
      device = self.device
      grad_V3 = torch.zeros_like(x, dtype=6, layout=None, device=device)
      grad_V0 = grad_V3
    _13 = torch.pow(torch.select(torch.slice(x), 1, 0), 2)
    _14 = torch.reshape(_13, [-1, 1, 1])
    _15 = torch.select(torch.slice(grad_V0), 1, 1)
    _16 = torch.reshape(torch.slice(_15, 1), [-1, 1, 1])
    W = torch.add(_14, _16)
    h = torch.matmul(torch.transpose(grad_V0, 1, 2), torch.matmul(g0, beta0))
    _17 = torch.transpose(grad_V0, 1, 2)
    _18 = torch.add(f0, torch.matmul(g0, alpha))
    _19 = torch.add(torch.matmul(_17, _18), W)
    _20 = torch.sum(torch.pow(grad_V0, 2), [1], True)
    _21 = torch.div(_19, torch.add(_20, 0.0001))
    criterion = torch.relu(_21)
    fs = torch.mul(torch.neg(criterion), grad_V0)
    f = torch.add(f0, fs)
    return (f, g0, alpha, V, h, beta0)

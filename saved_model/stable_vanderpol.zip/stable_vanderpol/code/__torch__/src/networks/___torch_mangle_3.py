class posLinear(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : NoneType
  training : bool
  _is_full_backward_hook : NoneType
  in_features : Final[int] = 32
  out_features : Final[int] = 1
  def forward(self: __torch__.src.networks.___torch_mangle_3.posLinear,
    input: Tensor) -> Tensor:
    weight = self.weight
    positive_weight = torch.softplus(torch.div(weight, 1))
    bias = self.bias
    _0 = torch.linear(input, positive_weight, bias)
    return _0

class Stable_Dynamics(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  device : Device
  state_dim : int
  action_dim : int
  x_stable : Tensor
  f_hat : __torch__.torch.nn.modules.container.Sequential
  lyapunov_function : __torch__.src.networks.LyapunovFunction
  alpha_hat : __torch__.torch.nn.modules.container.___torch_mangle_6.Sequential
  g : __torch__.torch.nn.modules.container.___torch_mangle_7.ModuleList
  def forward(self: __torch__.src.models.Stable_Dynamics,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
    f_hat = self.f_hat
    _0 = (f_hat).forward(x, )
    f_hat0 = self.f_hat
    x_stable = self.x_stable
    _1 = torch.sub(_0, (f_hat0).forward(x_stable, ))
    f0 = torch.unsqueeze(_1, 2)
    alpha_hat = self.alpha_hat
    _2 = (alpha_hat).forward(x, )
    alpha_hat0 = self.alpha_hat
    x_stable0 = self.x_stable
    _3 = torch.sub(_2, (alpha_hat0).forward(x_stable0, ))
    alpha = torch.unsqueeze(_3, 2)
    _4 = annotate(List[Tensor], [])
    g = self.g
    _00 = getattr(g, "0")
    _5 = (_00).forward(x, )
    state_dim = self.state_dim
    _6 = torch.reshape(_5, [-1, state_dim, 1])
    _7 = torch.append(_4, _6)
    g0 = torch.squeeze(torch.stack(_4, 2), 3)
    lyapunov_function = self.lyapunov_function
    V = (lyapunov_function).forward(x, )
    _8 = torch.autograd.grad([torch.sum(V)], [x], None, None, True)
    grad_V = _8[0]
    if torch.__isnot__(grad_V, None):
      grad_V1 = unchecked_cast(Tensor, grad_V)
      state_dim0 = self.state_dim
      grad_V2 = torch.reshape(grad_V1, [-1, state_dim0, 1])
      grad_V0 = grad_V2
    else:
      device = self.device
      grad_V3 = torch.zeros_like(x, dtype=6, layout=None, device=device)
      grad_V0 = grad_V3
    _9 = torch.sum(torch.pow(x, 2), [1], True)
    W = torch.mul(torch.unsqueeze(_9, 2), 0.10000000000000001)
    _10 = torch.transpose(grad_V0, 1, 2)
    _11 = torch.add(f0, torch.matmul(g0, alpha))
    _12 = torch.add(torch.matmul(_10, _11), W)
    _13 = torch.sum(torch.pow(grad_V0, 2), [1], True)
    _14 = torch.div(_12, torch.add(_13, 0.0001))
    criterion = torch.relu(_14)
    fs = torch.mul(torch.neg(criterion), grad_V0)
    f = torch.add(f0, fs)
    return (f, g0, alpha, V)
